#pragma once

#include "Vec3.hpp"

namespace RayTracingCPU{
    float random();
}
Vec3 randomNormalSphere();
Vec3 randomNormalDisk();
